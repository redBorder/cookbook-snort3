cookbook-barnyard2 CHANGELOG
===============

## 0.0.7

  - Miguel Negron
    - [2168330] Change cookbook owner
  - David Vanhoucke
    - [fa72c83] set correct http mode

This file is used to list changes made in each version of the example cookbook.

0.0.6
-----
- [David Vanhoucke <dvanhoucke@redborder.com]
  - Changed http to deflated mode

0.0.1
-----
- [Alberto Rodríguez <arodriguez@redborder.com]
  - COMMIT_REF Initial release of cookbook example

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
