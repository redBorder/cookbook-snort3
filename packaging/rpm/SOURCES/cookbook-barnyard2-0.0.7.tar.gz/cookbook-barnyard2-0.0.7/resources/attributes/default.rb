# Flags
default['barnyard2']['registered'] = false
default['redborder']['barnyard2']['service'] = 'barnyard2'
