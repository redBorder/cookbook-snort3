# Cookbook:: barnyard2
# Recipe:: default
# Copyright:: 2024, redborder
# License:: Affero General Public License, Version 3

barnyard2_config 'config' do
  action :add
end
